NEXORA OUTREACH
Files: wrangler.toml, worker.js, public/index.html

Cloudflare Builds:
Build command: leave blank
Deploy command: npx wrangler deploy

The /api/leads endpoint should be connected to the BizData service to make live lead finding work.
