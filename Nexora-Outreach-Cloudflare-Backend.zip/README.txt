NEXORA OUTREACH — CLOUDFLARE WORKER
======================================

Upload worker.js as a Cloudflare Worker.

Environment variables are optional:
- GEMINI_API_KEY
- WHATSAPP_TOKEN
- WHATSAPP_PHONE_NUMBER_ID

The worker can discover public business data through OpenStreetMap/Overpass
and can generate a message using Gemini if a key is supplied.

WhatsApp sending is kept as a separate endpoint and should only be enabled
after the proper WhatsApp Business Platform setup and messaging permissions
are in place.

This file is a backend foundation; it is not a complete unattended mass-
messaging system.
