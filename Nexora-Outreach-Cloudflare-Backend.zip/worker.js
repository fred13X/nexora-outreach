/**
 * Nexora Outreach — Cloudflare Worker backend
 *
 * SAFE FIRST VERSION:
 * - /api/health          -> health check
 * - /api/leads           -> searches public OpenStreetMap/Overpass data
 * - /api/dashboard       -> simple dashboard stats
 *
 * Optional integrations are intentionally behind environment variables:
 * GEMINI_API_KEY
 * WHATSAPP_TOKEN
 * WHATSAPP_PHONE_NUMBER_ID
 *
 * The Worker does NOT send WhatsApp messages automatically by default.
 * This prevents accidental bulk messaging while the connection is being tested.
 *
 * Deploy as a Cloudflare Worker. After deployment, the dashboard can call:
 *   GET https://YOUR-WORKER/api/leads?city=Manchester&category=hotel&limit=10
 */

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization"
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data, null, 2), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", ...CORS }
  });
}

function normaliseCategory(category) {
  const map = {
    hotel: '["tourism"="hotel"]',
    guest_house: '["tourism"="guest_house"]',
    hostel: '["tourism"="hostel"]',
    restaurant: '["amenity"="restaurant"]',
    cafe: '["amenity"="cafe"]',
    hairdresser: '["shop"="hairdresser"]',
    beauty: '["shop"="beauty"]',
    gym: '["leisure"="fitness_centre"]'
  };
  return map[category] || map.hotel;
}

async function geocode(city) {
  const url = "https://nominatim.openstreetmap.org/search?format=json&limit=1&q=" +
    encodeURIComponent(city);
  const r = await fetch(url, {
    headers: { "User-Agent": "NexoraOutreach/1.0 contact@example.invalid" }
  });
  if (!r.ok) throw new Error("Geocoding failed");
  const a = await r.json();
  if (!a.length) throw new Error("Location not found");
  return { lat: Number(a[0].lat), lon: Number(a[0].lon) };
}

async function findLeads(city, category, limit) {
  const { lat, lon } = await geocode(city);
  const tag = normaliseCategory(category);
  const radius = 25000;

  const query = `
[out:json][timeout:20];
(
  nwr${tag}(around:${radius},${lat},${lon});
);
out center tags ${Math.min(limit, 50)};
`;

  const r = await fetch("https://overpass-api.de/api/interpreter", {
    method: "POST",
    headers: { "content-type": "text/plain" },
    body: query
  });

  if (!r.ok) throw new Error("Public business-data service timed out or failed");

  const data = await r.json();
  const elements = Array.isArray(data.elements) ? data.elements : [];

  return elements.map((e, i) => {
    const t = e.tags || {};
    const c = e.center || e;
    return {
      id: String(e.id),
      name: t.name || "Unnamed business",
      category,
      phone: t.phone || t["contact:phone"] || "",
      website: t.website || t["contact:website"] || "",
      address: [t["addr:housenumber"], t["addr:street"], t["addr:postcode"]]
        .filter(Boolean).join(", "),
      latitude: c.lat,
      longitude: c.lon,
      opportunity: t.website ? "Website found — review quality" : "No website listed",
      score: Math.max(60, 96 - i)
    };
  }).filter(x => x.name !== "Unnamed business");
}

async function generateMessage(env, lead) {
  if (!env.GEMINI_API_KEY) {
    return {
      mode: "template",
      message:
        `Hi ${lead.name}, I came across your business and wanted to reach out. ` +
        `I build modern, affordable websites for businesses that want a stronger online presence. ` +
        `If you'd like, I can show you what a refreshed site could look like for ${lead.name}.`
    };
  }

  const prompt = `Write a short, professional cold outreach message for a business website service.
Business: ${lead.name}
Industry: ${lead.category}
Website listed: ${lead.website || "none listed"}
Opportunity: ${lead.opportunity}
Rules: be honest, no fake familiarity, no guarantees, no pressure, under 90 words.`;

  const r = await fetch(
    "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" +
      encodeURIComponent(env.GEMINI_API_KEY),
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }]
      })
    }
  );

  if (!r.ok) throw new Error("AI generation failed");
  const data = await r.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error("AI returned no message");

  return { mode: "gemini", message: text.trim() };
}

async function sendWhatsApp(env, to, message) {
  if (!env.WHATSAPP_TOKEN || !env.WHATSAPP_PHONE_NUMBER_ID) {
    throw new Error("WhatsApp Business Cloud credentials are not configured");
  }

  const url =
    `https://graph.facebook.com/v23.0/${env.WHATSAPP_PHONE_NUMBER_ID}/messages`;

  const r = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${env.WHATSAPP_TOKEN}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to,
      type: "text",
      text: { body: message }
    })
  });

  const data = await r.json();
  if (!r.ok) throw new Error(JSON.stringify(data));
  return data;
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: CORS });
    }

    const url = new URL(request.url);

    try {
      if (url.pathname === "/api/health") {
        return json({
          ok: true,
          service: "Nexora Outreach",
          integrations: {
            leadData: "OpenStreetMap/Overpass",
            ai: Boolean(env.GEMINI_API_KEY),
            whatsapp: Boolean(env.WHATSAPP_TOKEN && env.WHATSAPP_PHONE_NUMBER_ID)
          }
        });
      }

      if (url.pathname === "/api/leads" && request.method === "GET") {
        const city = url.searchParams.get("city") || "Manchester, UK";
        const category = url.searchParams.get("category") || "hotel";
        const limit = Math.max(1, Math.min(50, Number(url.searchParams.get("limit") || 10)));
        const leads = await findLeads(city, category, limit);
        return json({ city, category, count: leads.length, leads });
      }

      if (url.pathname === "/api/message" && request.method === "POST") {
        const lead = await request.json();
        return json(await generateMessage(env, lead));
      }

      // Deliberately separate from the lead finder. Keep sending disabled until
      // the WhatsApp Business connection and messaging permissions are configured.
      if (url.pathname === "/api/whatsapp/send" && request.method === "POST") {
        const body = await request.json();
        if (!body?.to || !body?.message) {
          return json({ error: "to and message are required" }, 400);
        }
        const result = await sendWhatsApp(env, body.to, body.message);
        return json({ ok: true, result });
      }

      if (url.pathname === "/api/dashboard") {
        return json({
          found: 0,
          ready: 0,
          sent: 0,
          replies: 0,
          note: "Connect persistent storage for live tracking."
        });
      }

      return json({
        service: "Nexora Outreach",
        endpoints: [
          "/api/health",
          "/api/leads?city=Manchester%2C%20UK&category=hotel&limit=10",
          "/api/message (POST)",
          "/api/whatsapp/send (POST)",
          "/api/dashboard"
        ]
      });
    } catch (err) {
      return json({ error: String(err.message || err) }, 500);
    }
  }
};
